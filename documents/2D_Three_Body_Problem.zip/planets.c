/*
20 dicembre 2016    ©Federico Cacciotti

**********  INTEGRATORE NUMERICO PER IL PROBLEMA DEI TRE CORPI  **********

Questo programma è in grado di simulare le traiettorie orbitali relative al problema dei tre corpi.
E' possibile scegliere il sistema di riferimento tra quello sinodico e quello inerziale fisso 
commentando o meno la riga
    #define SYNODICAL_RF
ed impostando i parametri necessari a simulare l'evoluzione del sistema.


ESEMPIO 1
1 - Impostare il sistema di riferimento INERZIALE commentando la riga "#ifdef SYNODICAL_RF"
2 - impostare i seguenti parametri orbitali:
    #define POS1 {-1, 0}
    #define POS2 {1, 0}
    #define POS3 {0, 0}
    #define VEL1 {0.405916, 0.230163}
    #define VEL2 {0.405916, 0.230163}
    #define VEL3 {-0.405916*2, -0.230163*2}
    #define MASS1 1
    #define MASS2 1
    #define MASS3 1
3 - scegliere il tipo di integratore (per il sistema inerziale consiglio Eulero-Cromer)
4 - impostare i parametri di integrazione come i seguenti:
    #define dt 0.0000001
    #define T_MAX 15
    #define RESOLUTION 5000
5 - eseguire il codice.

ESEMPIO 2
1 - Impostare il sistema di riferimento SINODICO decommentando la riga "#ifdef SYNODICAL_RF"
2 - impostare i seguenti parametri orbitali:
    #define MU 0.0001
    #define PERIOD (2*M_PI)
    #define POS1 {MU, 0}
    #define POS2 {MU-1, 0}
    #define POS3 {1.049466716047, 0}
    #define VEL1 {0, 0}
    #define VEL2 {0, 0}
    #define VEL3 {0, -0.089584341733}
    #define MASS1 (1-MU)
    #define MASS2 MU
    #define MASS3 0.000001
3 - scegliere il tipo di integratore (per il sistema sinodico consiglio Runge-Kutta)
4 - impostare i parametri di integrazione come i seguenti:
    #define dt 0.00001
    #define T_MAX 800
    #define RESOLUTION 5000
5 - eseguire il codice.


Per altri parametri orbitali ho consultato i seguenti link:
http://journals.aps.org/prl/abstract/10.1103/PhysRevLett.110.114301
http://www.aanda.org/articles/aa/pdf/2005/12/aa1483.pdf
http://suki.ipb.ac.rs/3body/
*/

//librerie necessarie
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

//se definito le particelle 1 e 2 saranno bloccate nelle posizioni iniziali e la particella 3 sarà libera di muoversi in un sistema di riferimento non inerziale sinodicale
#define SYNODICAL_RF

//parametri da impostare se il sistema di riferimento scelto è quello sinodico
#ifdef SYNODICAL_RF
#define MU 0.000000003002
#define PERIOD (2*M_PI)
#define POS1 {-MU, 0}
#define POS2 {1-MU, 0}
#define POS3 {-0.99967, 0}
#define VEL1 {0, 0}
#define VEL2 {0, 0}
#define VEL3 {0, -0.000498097757361097}
#define MASS1 (1-MU)
#define MASS2 MU
#define MASS3 0.000001
#endif

//parametri da impostare se il sistema di riferimento scelto è quello inerziale
//orbite di default per sistema di riferimento inerziale (0 se si scelgono i parametri manualmente)
#ifndef SYNODICAL_RF
#define POS1 {-1, 0}
#define POS2 {1, 0}
#define POS3 {0, 0}
#define VEL1 {0.405916, 0.230163}
#define VEL2 {0.405916, 0.230163}
#define VEL3 {-0.405916*2, -0.230163*2}
#define MASS1 1
#define MASS2 1
#define MASS3 1
#endif

//metodi di integrazione: decommentare SOLO il metodo da utilizzare
//#define EULERO_CROMER
#define RUNGE_KUTTA_2
//#define VERLET

//IMPOSTAZIONI PER L'INTEGRAZIONE
#define dt 0.00001          //intervallo di integrazione
#define G 1                 //costante gravitazionale
#define T_MAX 800           //tempo massimo di integrazione
#define GNUPLOT 1           //se = 1 esegue automaticamente i comandi per gnuplot nel file 'cmd.gp'
#define RESOLUTION 5000     //risoluzione per il plot

//se definito, il programma blocca l'integrazione quando due dei tre corpi si trovano ad una distanza minore di EPSILON
//#define COLLISION
#define EPSILON 0.00001         //distanza minima tra due particelle

//se definito creo un file di log con i risultati delle integrazioni
#define LOG_FILE
#ifdef LOG_FILE
FILE *result_log;
#endif

//definisco una struct con le coordinate spaziali
typedef struct COORDINATES{
    double x;
    double y;
} coordinates; 

//definisco una struct con le caratteristiche e le proprietà dei corpi
typedef struct PLANET{
    coordinates initPos;
    coordinates initVel;

    coordinates pos;
    coordinates vel;

    double mass;
} planets;

//definisco una struct con tutti i parametri del moto
typedef struct PARAMETERS{
    coordinates body1_pos, body2_pos, body3_pos;
    coordinates body1_vel, body2_vel, body3_vel;
} parameters;

//inizializzazione funzioni utili
parameters integrator(planets, planets, planets);
coordinates phi(planets, planets, planets);
void initialConditions(planets *, planets *, planets *);
void updateParameters(planets *, planets *, planets *, parameters);
void effectivePotential(planets, planets, planets);
void printInitialConditions(planets, planets, planets);
coordinates mult(coordinates, double);
coordinates sum(coordinates, coordinates);
coordinates sub(coordinates, coordinates);
double norm(coordinates);


int main(){
    //variabili utili
    clock_t begin_time = clock(), end_time;
    unsigned long long int i, j;
    parameters param;
    unsigned long long int steps = (unsigned long long int)(T_MAX/dt);    //numero di passi di integrazione

    planets body1, body2, body3;                    //definisco i tre corpi
    initialConditions(&body1, &body2, &body3);      //scelgo le condizioni iniziali

    FILE *output = fopen("data.dat", "w");          //file dati

    #ifdef LOG_FILE
    result_log = fopen("result_log.txt", "a+");     //file di log
    #endif

    printInitialConditions(body1, body2, body3);    //stampo su schermo le condizioni iniziali

    //eseguo l'integrazione
    for(i=0; i<steps; i++){
        //passo di integrazione
        param = integrator(body1, body2, body3);
        updateParameters(&body1, &body2, &body3, param);

        //scrittura su file
        if(i%RESOLUTION == 0){
            fprintf(output, "%.7lf\t%.7lf\t%.7lf\t%.7lf\t%.7lf\t%.7lf\t%.7lf\t%.7lf\n", body1.pos.x, body1.pos.y, body2.pos.x, body2.pos.y, body3.pos.x, body3.pos.y, body3.vel.x, body3.vel.y);
        }

        #ifdef COLLISION
        //blocco l'integrazione se la distanza tra due corpi è minore di EPSILON
        if(sqrt(pow(body1.pos.x - body2.pos.x, 2) + pow(body1.pos.y - body2.pos.y, 2)) < EPSILON || 
           sqrt(pow(body1.pos.x - body3.pos.x, 2) + pow(body1.pos.y - body3.pos.y, 2)) < EPSILON ||
           sqrt(pow(body3.pos.x - body2.pos.x, 2) + pow(body3.pos.y - body2.pos.y, 2)) < EPSILON){
            double complete = 100.*(double)i/((double)(T_MAX/dt));
            printf("\nIntegrazione arrestata al passo %llu (%.2lf%%) a causa di una collisione.\n", i, complete);
            #ifdef LOG_FILE
            fprintf(result_log, "\nIntegrazione arrestata al passo %llu (%.2lf%%) a causa di una collisione.\n", i, complete);
            #endif
            i = steps;
        }
        #endif
    }

    fclose(output);

    end_time = clock();
    double execution_time = ((double)end_time - (double)begin_time)/(double)CLOCKS_PER_SEC;
    printf("Tempo di esecuzione: %lf secondi.\n", execution_time);

    #ifdef LOG_FILE
    fprintf(result_log, "Tempo di esecuzione: %lf secondi.\n", execution_time);
    #endif


    #ifdef SYNODICAL_RF
    if(GNUPLOT){
        printf("Creazione grafici in corso...\n");
        system("gnuplot -p 'synodical_plot.gp'");
    }
    #else
    if(GNUPLOT){
        printf("Creazione grafici in corso...\n");
        system("gnuplot -p 'inertial_plot.gp'");
    }
    #endif

    //scrivo sul file il log dell'integrazione
    #ifdef LOG_FILE
    fclose(result_log);
    #endif

    return 0;
}


//scelgo le condizioni iniziali del sistema
void initialConditions(planets *body1, planets *body2, planets *body3){
    //inizializzazione parametri
    //corpo 1
    body1->initPos = (coordinates) POS1;
    body1->initVel = (coordinates) VEL1;
    body1->mass = MASS1;

    //corpo 2
    body2->initPos = (coordinates) POS2;
    body2->initVel = (coordinates) VEL2;
    body2->mass = MASS2;

    //corpo 3
    body3->initPos = (coordinates) POS3;
    body3->initVel = (coordinates) VEL3;
    body3->mass = MASS3;

    //valori iniziali
    body1->pos = body1->initPos;
    body1->vel = body1->initVel;
    body2->pos = body2->initPos;
    body2->vel = body2->initVel;
    body3->pos = body3->initPos;
    body3->vel = body3->initVel;
}

//funzione che scrive su schermo le condizioni iniziali
void printInitialConditions(planets body1, planets body2, planets body3){
    printf("\n********  INTEGRATORE NUMERICO DEL PROBLEMA DEI TRE CORPI  ********\n\n");
    //informazioni generali
    printf("Sitema di riferimento scelto: ");
    #ifdef SYNODICAL_RF
    printf("sinodico\n");
    #else
    printf("inerziale\n");
    #endif

    printf("Algoritmo di integrazione impostato: ");
    #ifdef EULERO_CROMER
    printf("Eulero-Cromer\n");
    #endif
    #ifdef RUNGE_KUTTA_2
    printf("Runge-Kutta al secondo ordine\n");
    #endif
    #ifdef VERLET
    printf("Verlet autosufficiente\n");
    #endif

    printf("Arresto collisioni: ");
    #ifdef COLLISION
    printf("attivo\n"
           "Distanza minima permessa: \t %lf\n", (double)EPSILON);
    #else
    printf("non attivo\n");
    #endif

    printf("Scrittura su file ogni %d integrazioni\n", RESOLUTION);

    //parametri iniziali dei corpi
    printf("\n*** Parametri orbitali del corpo 1 **\n"
           "Posizione iniziale: \t (%lf, %lf)\n"
           "Velocità iniziale:  \t (%lf, %lf)\n"
           "Massa: \t %lf\n", body1.initPos.x, body1.initPos.y, body1.initVel.x, body1.initVel.y, body1.mass);
    printf("\n*** Parametri orbitali del corpo 2 **\n"
           "Posizione iniziale: \t (%lf, %lf)\n"
           "Velocità iniziale:  \t (%lf, %lf)\n"
           "Massa: \t %lf\n", body2.initPos.x, body2.initPos.y, body2.initVel.x, body2.initVel.y, body2.mass);
    printf("\n*** Parametri orbitali del corpo 3 **\n"
           "Posizione iniziale: \t (%lf, %lf)\n"
           "Velocità iniziale:  \t (%lf, %lf)\n"
           "Massa: \t %lf\n", body3.initPos.x, body3.initPos.y, body3.initVel.x, body3.initVel.y, body3.mass);

    printf("\nIntegrazione in corso... \n"
           "Step di integrazione: \t %.10lf\n"
           "Tempo di integrazione: \t %lf\n"
           "Passi di integrazione: \t %d\n", dt, (double)T_MAX, (int)(T_MAX/dt));

    #ifdef LOG_FILE
    fprintf(result_log, "\n********  INTEGRATORE NUMERICO DEL PROBLEMA DEI TRE CORPI  ********\n\n");
    //informazioni generali
    fprintf(result_log, "Sitema di riferimento scelto: ");
    #ifdef SYNODICAL_RF
    fprintf(result_log, "sinodico\n");
    #else
    fprintf(result_log, "inerziale\n");
    #endif

    fprintf(result_log, "Algoritmo di integrazione impostato: ");
    #ifdef EULERO_CROMER
    fprintf(result_log, "Eulero-Cromer\n");
    #endif
    #ifdef RUNGE_KUTTA_2
    fprintf(result_log, "Runge-Kutta al secondo ordine\n");
    #endif
    #ifdef VERLET
    fprintf(result_log, "Verlet autosufficiente\n");
    #endif

    fprintf(result_log, "Arresto collisioni: ");
    #ifdef COLLISION
    fprintf(result_log, "attivo\n"
            "Distanza minima permessa: \t %lf\n", (double)EPSILON);
    #else
    fprintf(result_log, "non attivo\n");
    #endif

    fprintf(result_log, "Scrittura su file ogni %d integrazioni\n", RESOLUTION);

    //parametri iniziali dei corpi
    fprintf(result_log, "\n*** Parametri orbitali del corpo 1 **\n"
            "Posizione iniziale: \t (%lf, %lf)\n"
            "Velocità iniziale:  \t (%lf, %lf)\n"
            "Massa: \t %lf\n", body1.initPos.x, body1.initPos.y, body1.initVel.x, body1.initVel.y, body1.mass);
    fprintf(result_log, "\n*** Parametri orbitali del corpo 2 **\n"
            "Posizione iniziale: \t (%lf, %lf)\n"
            "Velocità iniziale:  \t (%lf, %lf)\n"
            "Massa: \t %lf\n", body2.initPos.x, body2.initPos.y, body2.initVel.x, body2.initVel.y, body2.mass);
    fprintf(result_log, "\n*** Parametri orbitali del corpo 3 **\n"
            "Posizione iniziale: \t (%lf, %lf)\n"
            "Velocità iniziale:  \t (%lf, %lf)\n"
            "Massa: \t %lf\n", body3.initPos.x, body3.initPos.y, body3.initVel.x, body3.initVel.y, body3.mass);

    fprintf(result_log, "\nIntegrazione in corso... \n"
            "Step di integrazione: \t %.10lf\n"
            "Tempo di integrazione: \t %lf\n"
            "Passi di integrazione: \t %d\n", dt, (double)T_MAX, (int)(T_MAX/dt));
    #endif
}

//funzione per aggiornare i parametri di moto delle particelle
void updateParameters(planets *body1, planets *body2, planets *body3, parameters param){

    #ifdef SYNODICAL_RF  //se il riferimento scelto è quello non inerziale si muove solo il corpo 3
    //corpo 3
    body3->pos = param.body3_pos;
    body3->vel = param.body3_vel;
    #else
    //corpo 1
    body1->pos = param.body1_pos;
    body1->vel = param.body1_vel;

    //corpo 2
    body2->pos = param.body2_pos;
    body2->vel = param.body2_vel;

    //corpo 3
    body3->pos = param.body3_pos;
    body3->vel = param.body3_vel;
    #endif
}

//algoritmo di integrazione
parameters integrator(planets bodyA, planets bodyB, planets bodyC){
    coordinates pos_plus, vel_plus;
    coordinates phi_, phi_np;
    parameters p;
    planets body_plus;


    #ifdef EULERO_CROMER
    #ifdef SYNODICAL_RF
    //corpo 3
    phi_ = phi(bodyC, bodyA, bodyB);
    p.body3_vel = sum(bodyC.vel, mult(phi_, dt));
    p.body3_pos = sum(bodyC.pos, mult(p.body3_vel, dt));
    #else
    //corpo 1
    phi_ = phi(bodyA, bodyB, bodyC);
    p.body1_vel = sum(bodyA.vel, mult(phi_, dt));
    p.body1_pos = sum(bodyA.pos, mult(p.body1_vel, dt));

    //corpo 2
    phi_ = phi(bodyB, bodyA, bodyC);
    p.body2_vel = sum(bodyB.vel, mult(phi_, dt));
    p.body2_pos = sum(bodyB.pos, mult(p.body2_vel, dt));

    //corpo 3
    phi_ = phi(bodyC, bodyA, bodyB);
    p.body3_vel = sum(bodyC.vel, mult(phi_, dt));
    p.body3_pos = sum(bodyC.pos, mult(p.body3_vel, dt));
    #endif
    #endif

    #ifdef RUNGE_KUTTA_2
    #ifdef SYNODICAL_RF
    //corpo 3
    body_plus = bodyC;
    phi_ = phi(bodyC, bodyA, bodyB);
    pos_plus = mult(bodyC.vel, dt);
    vel_plus = mult(phi_, dt);
    p.body3_pos = sum(bodyC.pos, mult((sum(bodyC.vel, mult(vel_plus, 0.5))), dt));
    body_plus.pos = sum(bodyC.pos, mult(pos_plus, 0.5));
    body_plus.vel = sum(bodyC.vel, mult(vel_plus, 0.5));
    phi_ = phi(body_plus, bodyA, bodyB);
    p.body3_vel = sum(bodyC.vel, mult(phi_, dt));
    #else
    //corpo 1
    body_plus = bodyA;
    phi_ = phi(bodyA, bodyB, bodyC);
    pos_plus = mult(bodyA.vel, dt);
    vel_plus = mult(phi_, dt);
    p.body1_pos = sum(bodyA.pos, mult((sum(bodyA.vel, mult(vel_plus, 0.5))), dt));
    body_plus.pos = sum(bodyA.pos, mult(pos_plus, 0.5));
    body_plus.vel = sum(bodyA.vel, mult(vel_plus, 0.5));
    phi_ = phi(body_plus, bodyB, bodyC);
    p.body1_vel = sum(bodyA.vel, mult(phi_, dt));

    //corpo 2
    body_plus = bodyB;
    phi_ = phi(bodyB, bodyA, bodyC);
    pos_plus = mult(bodyB.vel, dt);
    vel_plus = mult(phi_, dt);
    p.body2_pos = sum(bodyB.pos, mult((sum(bodyB.vel, mult(vel_plus, 0.5))), dt));
    body_plus.pos = sum(bodyB.pos, mult(pos_plus, 0.5));
    body_plus.vel = sum(bodyB.vel, mult(vel_plus, 0.5));
    phi_ = phi(body_plus, bodyA, bodyC);
    p.body2_vel = sum(bodyB.vel, mult(phi_, dt));

    //corpo 3
    body_plus = bodyC;
    phi_ = phi(bodyC, bodyA, bodyB);
    pos_plus = mult(bodyC.vel, dt);
    vel_plus = mult(phi_, dt);
    p.body3_pos = sum(bodyC.pos, mult((sum(bodyC.vel, mult(vel_plus, 0.5))), dt));
    body_plus.pos = sum(bodyC.pos, mult(pos_plus, 0.5));
    body_plus.vel = sum(bodyC.vel, mult(vel_plus, 0.5));
    phi_ = phi(body_plus, bodyA, bodyB);
    p.body3_vel = sum(bodyC.vel, mult(phi_, dt));
    #endif
    #endif

    #ifdef VERLET
    #ifdef SYNODICAL_RF
    //corpo 3
    phi_ = phi(bodyC, bodyA, bodyB);
    p.body3_pos = sum(sum(bodyC.pos, mult(bodyC.vel, dt)), mult(phi_ ,0.5*dt*dt));
    phi_np = phi(bodyC, bodyA, bodyB);
    p.body3_vel = sum(bodyC.vel, mult(sum(phi_, phi_np), 0.5*dt));
    #else
    //corpo 1
    phi_ = phi(bodyA, bodyB, bodyC);
    p.body1_pos = sum(sum(bodyA.pos, mult(bodyA.vel, dt)), mult(phi_ ,0.5*dt*dt));
    phi_np = phi(bodyA, bodyB, bodyC);
    p.body1_vel = sum(bodyA.vel, mult(sum(phi_, phi_np), 0.5*dt));

    //corpo 2
    phi_ = phi(bodyB, bodyA, bodyC);
    p.body2_pos = sum(sum(bodyB.pos, mult(bodyB.vel, dt)), mult(phi_ ,0.5*dt*dt));
    phi_np = phi(bodyB, bodyA, bodyC);
    p.body2_vel = sum(bodyB.vel, mult(sum(phi_, phi_np), 0.5*dt));

    //corpo 3
    phi_ = phi(bodyC, bodyA, bodyB);
    p.body3_pos = sum(sum(bodyC.pos, mult(bodyC.vel, dt)), mult(phi_ ,0.5*dt*dt));
    phi_np = phi(bodyC, bodyA, bodyB);
    p.body3_vel = sum(bodyC.vel, mult(sum(phi_, phi_np), 0.5*dt));
    #endif
    #endif

    return p;
}

//accelerazione
coordinates phi(planets bodyA, planets bodyB, planets bodyC){
    #ifndef SYNODICAL_RF
    double A = G*bodyB.mass;
    double B = G*bodyC.mass;
    double distanceAB3 = pow(norm(sub(bodyA.pos, bodyB.pos)), 3.);
    double distanceAC3 = pow(norm(sub(bodyA.pos, bodyC.pos)), 3.);

    A = A/distanceAB3;
    B = B/distanceAC3;

    return sum(mult(sub(bodyB.pos, bodyA.pos), A), mult(sub(bodyC.pos, bodyA.pos), B));  //phi: nelle sottrazioni ho invertito i termini cosi in A e B tolgo il segno -
    #else
    coordinates t = {2*bodyA.vel.y + bodyA.pos.x, -2*bodyA.vel.x + bodyA.pos.y};

    double A = G*bodyB.mass;
    double B = G*bodyC.mass;
    double distanceAB3 = pow(norm(sub(bodyA.pos, bodyB.pos)), 3.);
    double distanceAC3 = pow(norm(sub(bodyA.pos, bodyC.pos)), 3.);

    A = A/distanceAB3;
    B = B/distanceAC3;

    return sum(t, sum(mult(sub(bodyB.pos, bodyA.pos), A), mult(sub(bodyC.pos, bodyA.pos), B)));  //phi: nelle sottrazioni ho invertito i termini cosi in A e B tolgo il segno -
    #endif
}

//funzione che restituisce il prodotto tra un vettore ed uno scalare
coordinates mult(coordinates vector, double a){
    vector.x *= a;
    vector.y *= a;
    return vector;
}

//funzione che restituisce la somma tra due vettori
coordinates sum(coordinates a, coordinates b){
    a.x += b.x;
    a.y += b.y;
    return a;
}

//funzione che restituisce la differenza tra due vettori
coordinates sub(coordinates a, coordinates b){
    a.x -= b.x;
    a.y -= b.y;
    return a;
}

//funzione che restituisce la norma di un vettore
double norm(coordinates a){
    return sqrt(a.x*a.x + a.y*a.y);
}