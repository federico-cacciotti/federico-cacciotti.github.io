/*
20 dicembre 2016    ©Federico Cacciotti

Alcuni esempi di configurazioni iniziali per l'integrazione di orbite chiuse

*/

#if DEF_ORBIT != 0
    #define MASS1 1
    #define MASS2 1
    #define MASS3 1
#endif

#if DEF_ORBIT == 1
    #define P1 0.347111
    #define P2 0.532728
    #define POS1 {-1, 0}
    #define POS2 {1, 0}
    #define POS3 {0, 0}
    #define VEL1 {P1, P2}
    #define VEL2 {P1, P2}
    #define VEL3 {-2*P1, -2*P2}
    #define FILENAME "default1.dat"
#endif

#if DEF_ORBIT == 2
    #define P1 0.306893
    #define P2 0.125507
    #define POS1 {-1, 0}
    #define POS2 {1, 0}
    #define POS3 {0, 0}
    #define VEL1 {P1, P2}
    #define VEL2 {P1, P2}
    #define VEL3 {-2*P1, -2*P2}
#endif

#if DEF_ORBIT == 3
    #define P1 0.392955
    #define P2 0.097579
    #define POS1 {-1, 0}
    #define POS2 {1, 0}
    #define POS3 {0, 0}
    #define VEL1 {P1, P2}
    #define VEL2 {P1, P2}
    #define VEL3 {-2*P1, -2*P2}
#endif

#if DEF_ORBIT == 4
    #define P1 0.184279
    #define P2 0.587188
    #define POS1 {-1, 0}
    #define POS2 {1, 0}
    #define POS3 {0, 0}
    #define VEL1 {P1, P2}
    #define VEL2 {P1, P2}
    #define VEL3 {-2*P1, -2*P2}
#endif

#if DEF_ORBIT == 5
    #define P1 0.080584
    #define P2 0.588836
    #define POS1 {-1, 0}
    #define POS2 {1, 0}
    #define POS3 {0, 0}
    #define VEL1 {P1, P2}
    #define VEL2 {P1, P2}
    #define VEL3 {-2*P1, -2*P2}
#endif

#if DEF_ORBIT == 6
    #define P1 0.083300
    #define P2 0.127889
    #define POS1 {-1, 0}
    #define POS2 {1, 0}
    #define POS3 {0, 0}
    #define VEL1 {P1, P2}
    #define VEL2 {P1, P2}
    #define VEL3 {-2*P1, -2*P2}
#endif

#if DEF_ORBIT == 7
    #define P1 0.464445
    #define P2 0.396060
    #define POS1 {-1, 0}
    #define POS2 {1, 0}
    #define POS3 {0, 0}
    #define VEL1 {P1, P2}
    #define VEL2 {P1, P2}
    #define VEL3 {-2*P1, -2*P2}
#endif

#if DEF_ORBIT == 8
    #define P1 0.439166
    #define P2 0.452968
    #define POS1 {-1, 0}
    #define POS2 {1, 0}
    #define POS3 {0, 0}
    #define VEL1 {P1, P2}
    #define VEL2 {P1, P2}
    #define VEL3 {-2*P1, -2*P2}
#endif

#if DEF_ORBIT == 9
    #define P1 0.383444
    #define P2 0.377364
    #define POS1 {-1, 0}
    #define POS2 {1, 0}
    #define POS3 {0, 0}
    #define VEL1 {P1, P2}
    #define VEL2 {P1, P2}
    #define VEL3 {-2*P1, -2*P2}
#endif

#if DEF_ORBIT == 10
    #define P1 0.405916
    #define P2 0.230163
    #define POS1 {-1, 0}
    #define POS2 {1, 0}
    #define POS3 {0, 0}
    #define VEL1 {P1, P2}
    #define VEL2 {P1, P2}
    #define VEL3 {-2*P1, -2*P2}
#endif

#if DEF_ORBIT == 11
    #define P1 0.350112
    #define P2 0.079339
    #define POS1 {-1, 0}
    #define POS2 {1, 0}
    #define POS3 {0, 0}
    #define VEL1 {P1, P2}
    #define VEL2 {P1, P2}
    #define VEL3 {-2*P1, -2*P2}
#endif

#if DEF_ORBIT == 12
    #define P1 0.559064
    #define P2 0.349192
    #define POS1 {-1, 0}
    #define POS2 {1, 0}
    #define POS3 {0, 0}
    #define VEL1 {P1, P2}
    #define VEL2 {P1, P2}
    #define VEL3 {-2*P1, -2*P2}
#endif

#if DEF_ORBIT == 13
    #define P1 0.513938
    #define P2 0.304736
    #define POS1 {-1, 0}
    #define POS2 {1, 0}
    #define POS3 {0, 0}
    #define VEL1 {P1, P2}
    #define VEL2 {P1, P2}
    #define VEL3 {-2*P1, -2*P2}
#endif

#if DEF_ORBIT == 14
    #define P1 0.282699
    #define P2 0.327209
    #define POS1 {-1, 0}
    #define POS2 {1, 0}
    #define POS3 {0, 0}
    #define VEL1 {P1, P2}
    #define VEL2 {P1, P2}
    #define VEL3 {-2*P1, -2*P2}
#endif

#if DEF_ORBIT == 15
    #define P1 0.416822
    #define P2 0.330333
    #define POS1 {-1, 0}
    #define POS2 {1, 0}
    #define POS3 {0, 0}
    #define VEL1 {P1, P2}
    #define VEL2 {P1, P2}
    #define VEL3 {-2*P1, -2*P2}
#endif

#if DEF_ORBIT == 16
    #define P1 0.417343
    #define P2 0.313100
    #define POS1 {-1, 0}
    #define POS2 {1, 0}
    #define POS3 {0, 0}
    #define VEL1 {P1, P2}
    #define VEL2 {P1, P2}
    #define VEL3 {-2*P1, -2*P2}
#endif